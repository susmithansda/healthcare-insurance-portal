All media in this directory is original project artwork, generated specifically for CareClaim.

- `careclaim-walkthrough.mp4`: 16-second 960×540 H.264/YUV420p silent animated introduction, MP4 fast-start enabled.
- `walkthrough-poster.webp`: first-scene preview image.
- `walkthrough.en.vtt`: English text captions for the four scenes.
- `careclaim-calm.wav`: original 24-second, 22050 Hz, 16-bit stereo instrumental loop synthesized with sine tones. Playback starts only after user interaction.
- `generate_assets.py`: reproducible original asset generator; install Pillow and imageio-ffmpeg, then run with Python. Windows Segoe UI or Linux DejaVu Sans is used to render text.

The video uses synthetic people, claims, policy names, and transactions. It contains no recorded personal information and no spoken narration. The music is optional ambient sound, with no therapeutic claim.

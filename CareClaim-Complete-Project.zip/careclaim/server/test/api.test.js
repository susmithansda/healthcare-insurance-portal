import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHmac } from 'node:crypto';
import { createStore } from '../src/store.js';
import { createApp } from '../src/app.js';

const secret = 'careclaim-test-secret-with-at-least-32-characters';
async function setup(t, options = {}) {
  const dataDir = await mkdtemp(path.join(os.tmpdir(), 'careclaim-test-'));
  const store = await createStore({ dataDir });
  const app = createApp({ store, jwtSecret: secret, uploadDir: path.join(dataDir, 'uploads'), logger: { error: (...args) => { console.error(...args); } }, ...options });
  const server = app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { await new Promise(resolve => server.close(resolve)); await store.close(); await rm(dataDir, { recursive: true, force: true }); });
  async function request(url, { method = 'GET', token, body, form } = {}) {
    const response = await fetch(`${base}/api${url}`, { method, headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(body ? { 'content-type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : form ? { body: form } : {}) });
    const content = response.headers.get('content-type') || '';
    return { status: response.status, data: content.includes('application/json') ? await response.json() : await response.text() };
  }
  async function login(role = 'patient') { const r = await request('/auth/login', { method: 'POST', body: { email: `${role}@careclaim.demo`, password: 'Demo@12345' } }); assert.equal(r.status, 200); return r.data; }
  return { store, request, login, dataDir, base };
}
const claimBody = { policyNumber: 'CC-2026-104201', age: 32, gender: 'Male', claimAmount: 25000, disease: 'Hospital observation', hospital: 'Sample Medical Centre', admissionDate: '2026-01-11', dischargeDate: '2026-01-12' };

test('authentication, registration restrictions, duplicate emails and password privacy', async t => {
  const { request, login } = await setup(t);
  assert.equal((await request('/claims')).status, 401);
  assert.equal((await request('/auth/login', { method: 'POST' })).status, 400);
  assert.equal((await request('/auth/login', { method: 'POST', body: { email: 'patient@careclaim.demo', password: 'wrong' } })).status, 401);
  const session = await login(); assert.equal(session.user.role, 'patient'); assert.equal(session.user.passwordHash, undefined);
  const me = await request('/auth/me', { token: session.token }); assert.equal(me.data.user.id, 'user-patient'); assert.equal(me.data.user.passwordHash, undefined);
  const registration = { name: 'Test Patient', email: 'test@example.com', password: 'SecurePass123!' };
  assert.equal((await request('/auth/register', { method: 'POST', body: { ...registration, role: 'admin' } })).status, 403);
  const created = await request('/auth/register', { method: 'POST', body: registration }); assert.equal(created.status, 201); assert.equal(created.data.user.role, 'patient');
  assert.equal((await request('/auth/register', { method: 'POST', body: registration })).status, 409);
  assert.equal((await request('/auth/profile', { method: 'PUT', token: session.token, body: { name: 'Aarav S', phone: '9876543210', role: 'admin' } })).data.user.role, 'patient');
});

test('patient ownership, staff role boundaries and role-filtered analytics', async t => {
  const { request, login } = await setup(t);
  const patient = await login(), officer = await login('officer'), hospital = await login('hospital');
  const own = await request('/claims', { token: patient.token }); assert.ok(own.data.claims.every(c => c.patientId === patient.user.id)); assert.equal(own.data.claims.length, 4);
  assert.equal((await request('/claims/claim-5', { token: patient.token })).status, 404);
  assert.equal((await request('/claims', { token: officer.token })).data.claims.length, 8);
  assert.equal((await request('/claims/stats', { token: patient.token })).data.stats.totalClaims, 4);
  assert.equal((await request('/audit', { token: hospital.token })).status, 403);
  assert.equal((await request('/audit', { token: officer.token })).status, 200);
  assert.equal((await request('/payments/order', { method: 'POST', token: hospital.token, body: { policyId: 'policy-1' } })).status, 403);
});

test('claim validation, self-service edits and reviewer transitions are enforced', async t => {
  const { request, login } = await setup(t); const patient = await login(), officer = await login('officer');
  for (const body of [{ ...claimBody, claimAmount: -1 }, { ...claimBody, admissionDate: '2026-02-31' }, { ...claimBody, claimAmount: 1000001 }, { ...claimBody, policyNumber: 'CC-2026-104202' }, { ...claimBody, age: '' }]) assert.equal((await request('/claims', { method: 'POST', token: patient.token, body })).status, 400);
  const submitted = await request('/claims', { method: 'POST', token: patient.token, body: { ...claimBody, status: 'Approved', patientId: 'user-patient-2' } });
  assert.equal(submitted.status, 201); const c = submitted.data.claim; assert.equal(c.status, 'Pending'); assert.equal(c.patientId, patient.user.id);
  assert.equal((await request(`/claims/${c.id}`, { method: 'PUT', token: patient.token, body: { claimAmount: 27000 } })).data.claim.claimAmount, 27000);
  assert.equal((await request(`/claims/${c.id}`, { method: 'PUT', token: patient.token, body: { status: 'Approved', remarks: 'Please approve' } })).status, 403);
  assert.equal((await request(`/claims/${c.id}`, { method: 'PUT', token: officer.token, body: { status: 'Approved', remarks: '' } })).status, 400);
  const [a, b] = await Promise.all(['Approved', 'Rejected'].map(status => request(`/claims/${c.id}`, { method: 'PUT', token: officer.token, body: { status, remarks: 'Documents reviewed and verified.' } })));
  assert.deepEqual([a.status, b.status].sort(), [200, 409]);
  assert.equal((await request(`/claims/${c.id}`, { method: 'PUT', token: patient.token, body: { claimAmount: 20000 } })).status, 403);
});

test('uploaded documents require signatures and authenticated ownership', async t => {
  const { request, login } = await setup(t); const patient = await login();
  const invalid = new FormData(); invalid.append('documents', new Blob(['<script>alert(1)</script>'], { type: 'application/pdf' }), 'fake.pdf');
  assert.equal((await request('/claims/claim-3/documents', { method: 'POST', token: patient.token, form: invalid })).status, 400);
  const valid = new FormData(); valid.append('documents', new Blob(['%PDF-1.4\nSynthetic sample bill\n%%EOF'], { type: 'application/pdf' }), 'sample-bill.pdf');
  const added = await request('/claims/claim-3/documents', { method: 'POST', token: patient.token, form: valid }); assert.equal(added.status, 201);
  const doc = added.data.claim.documents[0]; assert.equal(doc.path, undefined); assert.equal(doc.name, 'sample-bill.pdf');
  assert.equal((await request(`/documents/${doc.id}`)).status, 401);
  assert.equal((await request(`/documents/${doc.id}`, { token: patient.token })).status, 200);
  const registration = await request('/auth/register', { method: 'POST', body: { name: 'Another Patient', email: 'another@example.com', password: 'SecurePass123!' } });
  assert.equal((await request(`/documents/${doc.id}`, { token: registration.data.token })).status, 404);
});

test('sandbox premiums use server amounts, disallow another patient and settle idempotently', async t => {
  const { request, login, store } = await setup(t); const patient = await login();
  assert.equal((await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-2' } })).status, 404);
  const checkout = await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1', amount: 1 } });
  assert.equal(checkout.status, 201); assert.equal(checkout.data.provider, 'demo'); assert.equal(checkout.data.order.amount, 1249900);
  const repeated = await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1' } }); assert.equal(repeated.data.order.id, checkout.data.order.id);
  const responses = await Promise.all([1, 2].map(() => request('/payments/verify', { method: 'POST', token: patient.token, body: { orderId: checkout.data.order.id } })));
  assert.ok(responses.every(r => r.status === 200)); assert.equal(responses[0].data.payment.id, responses[1].data.payment.id); assert.equal(store.read().payments.length, 1);
  assert.equal((await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1' } })).status, 409);
  assert.equal((await request('/payments', { token: patient.token })).data.payments.length, 1);
});

test('Razorpay requires a valid server signature AND a captured matching payment', async t => {
  let captured = false;
  const { request, login } = await setup(t, { razorpayKeyId: 'rzp_test_example', razorpayKeySecret: 'test-secret', demoPayments: false, gatewayFetch: async (url, options) => {
    if (url.endsWith('/orders')) { assert.equal(JSON.parse(options.body).amount, 1249900); return new Response(JSON.stringify({ id: 'order_gateway_123' })); }
    return new Response(JSON.stringify({ id: 'pay_gateway_123', status: captured ? 'captured' : 'authorized', order_id: 'order_gateway_123', amount: 1249900, currency: 'INR', method: 'upi' }));
  } });
  const patient = await login(); const order = await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1' } });
  assert.equal(order.data.provider, 'razorpay'); assert.equal(order.data.keyId, 'rzp_test_example');
  const body = { orderId: order.data.order.id, razorpay_payment_id: 'pay_gateway_123', razorpay_signature: '0'.repeat(64) };
  assert.equal((await request('/payments/verify', { method: 'POST', token: patient.token, body })).status, 400);
  body.razorpay_signature = createHmac('sha256', 'test-secret').update('order_gateway_123|pay_gateway_123').digest('hex');
  assert.equal((await request('/payments/verify', { method: 'POST', token: patient.token, body })).status, 409);
  captured = true;
  const verified = await request('/payments/verify', { method: 'POST', token: patient.token, body }); assert.equal(verified.status, 200); assert.equal(verified.data.payment.method, 'upi');
});

test('disabled sandbox refuses checkout without payment credentials', async t => {
  const { request, login } = await setup(t, { demoPayments: false }); const patient = await login();
  assert.equal((await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1' } })).status, 503);
});

test('signed captured-payment webhooks reconcile once and reject forged signatures', async t => {
  const { request, login, store, base } = await setup(t, { razorpayKeyId: 'rzp_test_example', razorpayKeySecret: 'gateway-secret', webhookSecret: 'webhook-secret', demoPayments: false, gatewayFetch: async () => new Response(JSON.stringify({ id: 'order_webhook_123' })) });
  const patient = await login(); const order = await request('/payments/order', { method: 'POST', token: patient.token, body: { policyId: 'policy-1' } });
  const body = JSON.stringify({ event: 'payment.captured', payload: { payment: { entity: { id: 'pay_webhook_123', order_id: 'order_webhook_123', amount: 1249900, currency: 'INR', status: 'captured', method: 'upi' } } } });
  const send = signature => fetch(`${base}/api/payments/webhook`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-razorpay-signature': signature }, body });
  assert.equal((await send('0'.repeat(64))).status, 400);
  const signature = createHmac('sha256', 'webhook-secret').update(body).digest('hex');
  assert.equal((await send(signature)).status, 200); assert.equal((await send(signature)).status, 200);
  assert.equal(store.read().payments.length, 1);
  const verify = await request('/payments/verify', { method: 'POST', token: patient.token, body: { orderId: order.data.order.id } }); assert.equal(verify.status, 200); assert.equal(verify.data.payment.gatewayPaymentId, 'pay_webhook_123');
});

test('demonstration records persist across reopen and failed mutations roll back', async t => {
  const { store, dataDir } = await setup(t);
  await store.mutate(state => { state.users[0].phone = '9123456789'; });
  await assert.rejects(store.mutate(state => { state.users[0].phone = 'bad'; throw new Error('Abort transaction'); }), /Abort transaction/);
  assert.equal(store.read().users[0].phone, '9123456789');
  const reopened = await createStore({ dataDir });
  assert.equal(reopened.read().users[0].phone, '9123456789');
  await reopened.close();
});
